Pledge: On my honor I have neither given nor received aid on this exam.

Archive Contents:
readme.txt - contains the pledge and what files are in the .zip as well as their
             description.

sde2.camel - contains the main program that implements the 6 required functions.

sde2.log - contains a log of the program working with at least two examples of each 
            problem set.