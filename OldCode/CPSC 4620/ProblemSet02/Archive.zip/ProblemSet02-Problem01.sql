-- ## Problem 1
-- 
-- Write a query to count the number of invoices.
-- 
-- +----------+
-- | COUNT(*) |
-- +----------+
-- |    8     |
-- +----------+
-- 
SELECT COUNT(*) AS `COUNT(*)`
FROM INVOICE;