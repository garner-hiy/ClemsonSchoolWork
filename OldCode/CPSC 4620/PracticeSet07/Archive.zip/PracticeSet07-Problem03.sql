-- ## Problem 3:
-- 
-- The Owner Relationship team realized that maintaining owners in two different tables is difficult.
-- Therefore, they indicated that they do not need the ACTIVE_OWNER table anymore. 
-- 
-- You need to delete the table from the database.

DROP TABLE ACTIVE_OWNER;
