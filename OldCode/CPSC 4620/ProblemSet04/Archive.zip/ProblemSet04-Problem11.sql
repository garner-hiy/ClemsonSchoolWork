-- ## Problem 11
-- 
-- Write a query to display the total value of all books in the library.
-- 
-- +---------------+
-- | Library Value |
-- +---------------+
-- |    1499.00    |
-- +---------------+

SELECT SUM(BOOK_COST) AS `Library Value`
FROM BOOK;