-- ## Problem 9
-- 
-- Update customer 1000 to have a date of birth on March 15, 1989.
-- 
-- NOTE: Use YYYY-MM-DD format for date values.
--

UPDATE CUSTOMER
SET CUST_DOB = '1989-03-15'
WHERE CUST_NUM = 1000;