Archive Contents:

HW1_AJ_Garner.pdf - Contains the report with screenshots
                    followed by comments explaining the tasks.

HW1code_AJ_Garner.cpp - Contains the source code for the program
          to find the Frequencies.

makefile - used to compile and run the program. Just type
            "make" to compile, then "make run" to run the program.
            Then just "make clean" when finished to clean up.

cipher.txt - contains the cipher text for the project

cipher_output_results.txt - results from running in the program

moby_dick.txt - contains about 70,000 letters from "Moby Dick"

moby_dick_output_results.txt - results from running in the program

war_and_peace.txt - Contains about 35,000 letters from "War and Peace".

war_and_peace_output_results.txt - results from running in the program