// ASG3
// Moises Martinez & Daniel Visser
// 7-30-2023
/* test driver */

#include "tfs.h"

int main(){
  unsigned int fd[20];
  char buffer1[1024], buffer2[1024], buffer3[1024];
  unsigned int length1, length2, length3, count1, count2, count3;
  
  sprintf( buffer1, "%s", "Modify one of the drivers to demonstrate that your added functions work and name it tfs_driver3.c. Credit on this item will depend on how persuasive you are that your added functions work. You will need to submit all files necessary to run your program (as a tarball) to canvas. Your archive should not have any subdirectories when unzipped, only .c files" );
  
  sprintf( buffer2, "%s", "This seems like a simple assignment, but you will need to spend some time understanding the structure and implementation of the existing code. This is a big part of the assignment. After you understand what is going on and how different files and functions inter-operate, you will be able to make additions to the code. Please make a plan and start right away.");

  sprintf( buffer3, "%s", "In this part of the assignment you will implement the tfs_delete(), tfs_read(), and tfs_write() functions for a trivial file system. These functions delete a file in the trivial file system, read a buffer of bytes from an existing file in the trivial file system, and write a buffer of bytes to an existing file in the trivial file system, respectively");

  length1 = strlen(buffer1);
  length2 = strlen(buffer2);
  length3 = strlen(buffer3);

  // Create file system
  tfs_init();

  tfs_list_directory();

  // Read/Write permission bits are set FALSE by default
  
  fd[0] = tfs_create("saucy.txt");
  if( fd[0] == 0 ) printf( "first create failed\n" );
  
  fd[1] = tfs_create("beans.txt");
  if( fd[0] == 0 ) printf( "second create failed\n" );

  fd[2] = tfs_create("teriderp");
  if( fd[0] == 0 ) printf( "third create failed\n" );

  // At this point, all 3 files should be in the directory with 
  // Read/Write permissions set to FALSE, and no content
  tfs_list_directory();

  // For now (while we are in the dark), the first write for a file
  // will set both Read/Write permission to TRUE

  // Write buffer1 to fd[0], will be fragmented due to
  // buffer size being > than BLOCK_SIZE * 1.5
  count1 = tfs_write(fd[0], buffer1, BLOCK_SIZE * 1.5);
  printf( "%d bytes written to first file\n", count1);

  // Write buffer1 to fd[1], will NOTE be fragmented due to
  // buffer size being > than BLOCK_SIZE * 1.5
  count2 = tfs_write(fd[1], buffer2, BLOCK_SIZE);
  printf( "%d bytes written to second file\n", count2);

  // Write buffer 3 to fd[2], will be fragmented due to 
  // buffer size being > (BLOCK_SIZE * 2)
  count3 = tfs_write(fd[2], buffer3, (BLOCK_SIZE * 2));
  printf( "%d bytes written to third file\n", count2);
  
  // Display directory and associated blocks
  tfs_list_directory();
  tfs_list_blocks();

  // Test to make fd[1] or "beans.txt" unwritable
  file_make_writable("beans.txt");
  
  //Attempt a write to "beans.txt"
  count2 = tfs_write(fd[1], buffer2 + BLOCK_SIZE, BLOCK_SIZE * 2);
  printf( "%d bytes written to second file\n", count2);
  // Attempt a write to "saucy"
  count1 = tfs_write(fd[0], buffer1 + (int)(BLOCK_SIZE * 1.5), BLOCK_SIZE * 1.5);
  printf( "%d bytes written to first file\n", count1);
  // Attempt a write to "teriderp"
  count3 = tfs_write(fd[2], buffer3 + BLOCK_SIZE * 2, BLOCK_SIZE);
  printf( "%d bytes written to third file\n", count2);

  // Display directory and associated blocks
  tfs_list_directory();
  tfs_list_blocks();
  
  // Attempt to read 640 bytes after seeking to 99th byte
  // Should only read 285 characters
  tfs_seek( fd[0], 99 );
  count3 = tfs_read( fd[0], buffer1, 640 );
  printf( "%d bytes read from first file\n", count3 );
  buffer1[count3] = '\0';
  printf( "[%s]\n", buffer1);

  // Make beans.txt (fd[1]) unreadable
  file_make_readable("beans.txt");
  // Attempt to read 'beans.txt' after seeking to 99th byte
  // Should be unsuccessful with read
  tfs_seek( fd[1], 99 );
  count3 = tfs_read( fd[1], buffer1, 640 );
  printf( "%d bytes read from second file\n", count3 );
  buffer1[count3] = '\0';
  printf( "[%s]\n", buffer1);

  // Attempt to read 'teriderp' after seeking to 30th byte
  // Should be successful  with read
  tfs_seek( fd[2], 30 );
  count3 = tfs_read( fd[2], buffer1, 10 );
  printf( "%d bytes read from second file\n", count3 );
  buffer1[count3] = '\0';
  printf( "[%s]\n", buffer1);

  // Display directory and associated blocks
  tfs_list_directory();
  tfs_list_blocks();

  // As a test, close fd[1] "beans.txt"
  tfs_close(fd[1]);

  // Display directory and associated blocks
  tfs_list_directory();
  tfs_list_blocks();

  // Delete all 3 files that were created
  tfs_delete(fd[0]);
  tfs_delete(fd[1]);
  tfs_delete(fd[2]);

  // Display directory and associated blocks
  tfs_list_directory();
  tfs_list_blocks();
}